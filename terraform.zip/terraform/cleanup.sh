#!/bin/bash
#!/bin/bash
rm -rf .terraform
rm -rf .cleanup*
rm -rf .terraform
rm *.tfstate*
rm .terraform.lock.hcl